response=("I love you")
response2=("i love you more")
response3=response + response2
print(response3)
question=("whats your name")
name=("Valeria")
print(f"{name} and  {question}")