
myvalue= True
print(myvalue)
print(type(myvalue))
print(str(myvalue) + "is my real value" + str(type(myvalue)))


