fruits = ["apple","banana","cherries"]
print(type(fruits))